Raspberry Pi 4 EEPROM bootloader rescue image
********************************************

The Raspberry Pi4 contains a small EEPROM used to contain the bootloader.
Normally, this is completely invisible but it it were to become corrupted
(e.g. due to a failed EEPROM upgrade or a broken image or incorrect usage
of flashrom) then the Pi4 will fail to boot.

This rescue image also updates the USB 3.0 (VL805) EEPROM to the latest
version which reduces power consumption.

To re-flash the EEPROM

1. Unzip the contents of this zip file to a blank FAT formatted SD-SDCARD.
2. Power off the Raspberry Pi
3. Insert the sd-card.
4. Power on Raspberry Pi
5. Wait at least 10 seconds.

If successful, the green LED light will blink rapidly (forever), otherwise
an error pattern will be displayed.

N.B. This image is not a bootloader it simply replaces the on-board bootloader.

